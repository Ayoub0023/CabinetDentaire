package com.cabinet.cabinetmedicale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabinetmedicaleApplicationTests {

    @Test
    void contextLoads() {
    }

}
