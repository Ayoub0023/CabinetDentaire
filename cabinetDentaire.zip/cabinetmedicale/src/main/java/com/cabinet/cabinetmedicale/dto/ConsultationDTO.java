package com.cabinet.cabinetmedicale.dto;

import com.cabinet.cabinetmedicale.entity.Acte;
import com.cabinet.cabinetmedicale.entity.InterventionMedecin;
import com.cabinet.cabinetmedicale.enums.CategorieActe;
import com.cabinet.cabinetmedicale.enums.Sexe;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConsultationDTO {

    private Long dent;//i_m
    private double prix;//i_m
    private LocalDate date;//dm
    private CategorieActe acte;//acte
    private String nom;
    private String prenom;
    private Sexe sexe;
    private String email;
    private String cin;
    private String adresse;
    private String tel;
    private LocalDate dateConsult;//c
    private List<InterventionMedecin> interventionsMedecin;
}
