package com.cabinet.cabinetmedicale.entity;

import com.cabinet.cabinetmedicale.enums.StatutPaiement;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "dossierMedicale")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DossierMedicale{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @CreationTimestamp
    private LocalDate dateCreation;
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "patientId")
    private Patient patient;
    @ManyToOne
    @JoinColumn(name = "dentiste_id")
    private Dentiste dentiste;
    private StatutPaiement statutPaiement;
    @OneToMany(mappedBy = "dossierMedicale", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Consultation> consultations =new ArrayList<>();


}
