package com.cabinet.cabinetmedicale.enums;

public enum Disponibilite
{
    MATIN,
    APRES_MIDI,
    TOUTE_LA_JOURNEE
}
