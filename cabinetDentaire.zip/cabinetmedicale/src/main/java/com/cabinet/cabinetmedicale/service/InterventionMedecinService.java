package com.cabinet.cabinetmedicale.service;

import com.cabinet.cabinetmedicale.repository.InterventionMedecinRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InterventionMedecinService {
    private final InterventionMedecinRepository interventionMedecinRepository;
    @Autowired
    public InterventionMedecinService(InterventionMedecinRepository interventionMedecinRepository) {
        this.interventionMedecinRepository = interventionMedecinRepository;
    }
}
