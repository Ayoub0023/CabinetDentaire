package com.cabinet.cabinetmedicale.dto;

import com.cabinet.cabinetmedicale.enums.Sexe;
import com.cabinet.cabinetmedicale.enums.StatutPaiement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SituationFinanciereDto {
    private LocalDate date;//f
    private Long numeroFacture;//f
    private StatutPaiement etat;//dm
    private double montant;//f

}
