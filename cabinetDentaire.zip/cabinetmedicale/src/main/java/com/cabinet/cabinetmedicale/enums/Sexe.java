package com.cabinet.cabinetmedicale.enums;

public enum Sexe {
    MASCULIN,
    FEMININ
}
