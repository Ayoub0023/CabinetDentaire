package com.cabinet.cabinetmedicale.enums;

public enum GroupeSanguin {
    A_POSITIF,
    A_NEGATIF,
    B_POSITIF,
    B_NEGATIF,
    AB_POSITIF,
    AB_NEGATIF,
    O_POSITIF,
    O_NEGATIF
}
