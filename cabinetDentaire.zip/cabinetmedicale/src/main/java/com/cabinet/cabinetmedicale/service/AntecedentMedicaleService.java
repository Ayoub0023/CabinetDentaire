package com.cabinet.cabinetmedicale.service;

import com.cabinet.cabinetmedicale.repository.AntecedentMedicaleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AntecedentMedicaleService {
    private final AntecedentMedicaleRepository antecedentMedicaleRepository;
    @Autowired
    public AntecedentMedicaleService(AntecedentMedicaleRepository antecedentMedicaleRepository) {
        this.antecedentMedicaleRepository = antecedentMedicaleRepository;
    }
}

