package com.cabinet.cabinetmedicale.controller;

import com.cabinet.cabinetmedicale.dto.ConsultationDTO;
import com.cabinet.cabinetmedicale.dto.SituationFinanciereDto;
import com.cabinet.cabinetmedicale.service.SituationFinanciereService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/patients")
public class SituationFinanciereController {
    private final SituationFinanciereService situationFinanciereService;

    public SituationFinanciereController(SituationFinanciereService situationFinanciereService) {
        this.situationFinanciereService = situationFinanciereService;
    }

}
