package com.cabinet.cabinetmedicale.repository;

import com.cabinet.cabinetmedicale.entity.Consultation;
import com.cabinet.cabinetmedicale.entity.DossierMedicale;
import com.cabinet.cabinetmedicale.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public interface ConsultationRepository extends JpaRepository<Consultation, Long> {
    Consultation findByDossierMedicale(DossierMedicale dossierMedicale);
    List<Consultation> findAllByDossierMedicale(DossierMedicale dossierMedicale);

}
