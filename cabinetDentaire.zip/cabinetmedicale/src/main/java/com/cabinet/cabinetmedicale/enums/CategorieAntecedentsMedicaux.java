package com.cabinet.cabinetmedicale.enums;

public enum CategorieAntecedentsMedicaux {
    MALADIR_CHRONIQUE(Risque.ELEVE),
    CONTRE_INDICATION(Risque.MOYEN),
    AUTRE(Risque.INCONNU),
    MALADIE_HEREDITAIRE(Risque.ELEVE),
    ALLERGIE(Risque.MOYEN);


    private Risque risqueAssocie;
    CategorieAntecedentsMedicaux(Risque risque) {
        this.risqueAssocie = risque;
    }

    public Risque getRisqueAssocie() {
        return risqueAssocie;
    }
    private String description;

    public void setRisqueAssocie(Risque risqueAssocie) {
        this.risqueAssocie = risqueAssocie;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
