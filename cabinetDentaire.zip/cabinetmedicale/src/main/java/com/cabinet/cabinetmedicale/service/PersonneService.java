package com.cabinet.cabinetmedicale.service;

import com.cabinet.cabinetmedicale.repository.PersonneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class PersonneService
{
    private final PersonneRepository personneRepository;

    @Autowired
    public PersonneService(PersonneRepository personneRepository)
    {
        this.personneRepository = personneRepository;
    }
    public void deletePersonne(Long id) {
        personneRepository.deleteById(id);
    }
}

