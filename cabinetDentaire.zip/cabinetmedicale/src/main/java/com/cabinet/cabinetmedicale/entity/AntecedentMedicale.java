package com.cabinet.cabinetmedicale.entity;

import com.cabinet.cabinetmedicale.enums.CategorieAntecedentsMedicaux;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "antecedent_medicale")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AntecedentMedicale {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String libelle;
    @ManyToMany
    @JoinTable(name = "antecedentMedicale_patient",
            joinColumns = @JoinColumn(name = "antecedentMedicale_id"),
            inverseJoinColumns = @JoinColumn(name = "patient_id"))
    private List<Patient> patientsAvecCeAntecedentMedicale;
    @Enumerated(EnumType.STRING)
    private CategorieAntecedentsMedicaux categorie;
    public void addPatient(Patient patient){
        if (patientsAvecCeAntecedentMedicale == null){
        this.patientsAvecCeAntecedentMedicale=new ArrayList<>();
        }
        patientsAvecCeAntecedentMedicale.add(patient);
    }


}

