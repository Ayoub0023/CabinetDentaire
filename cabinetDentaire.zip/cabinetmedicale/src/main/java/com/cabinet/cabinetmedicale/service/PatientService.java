package com.cabinet.cabinetmedicale.service;
import com.cabinet.cabinetmedicale.Exceptions.PatientCreationException;
import com.cabinet.cabinetmedicale.entity.Dentiste;
import com.cabinet.cabinetmedicale.entity.DossierMedicale;
import com.cabinet.cabinetmedicale.entity.Patient;
import com.cabinet.cabinetmedicale.entity.SituationFinanciere;
import com.cabinet.cabinetmedicale.enums.GroupeSanguin;
import com.cabinet.cabinetmedicale.enums.Mutuelle;
import com.cabinet.cabinetmedicale.enums.Sexe;
import com.cabinet.cabinetmedicale.enums.StatutPaiement;
import com.cabinet.cabinetmedicale.repository.DossierMedicaleRepository;
import com.cabinet.cabinetmedicale.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
@Service
public class PatientService {
    private final PatientRepository patientRepository;
    private final DossierMedicaleRepository dossierMedicaleRepository;
    @Autowired
    public PatientService(PatientRepository patientRepository, DossierMedicaleRepository dossierMedicaleRepository) {
        this.patientRepository = patientRepository;
        this.dossierMedicaleRepository = dossierMedicaleRepository;
    }
    public Patient creerPatient(String nom, String prenom, Sexe sexe, String adresse, String cin, String email, String telephone, LocalDate dateNaissance, String profession, GroupeSanguin groupeSanguin, Mutuelle mutuelle) {
        try {
            Patient patient = new Patient();
            patient.setNom(nom);
            patient.setPrenom(prenom);
            patient.setSexe(sexe);
            patient.setAdresse(adresse);
            patient.setCin(cin);
            patient.setEmail(email);
            patient.setTelephone(telephone);
            patient.setDateNaissance(dateNaissance);
            patient.setProfession(profession);
            patient.setGroupeSanguin(groupeSanguin);
            patient.setMutuelle(mutuelle);
            Patient savedPatient = patientRepository.save(patient);
            // Create and save the dossier medicale
            DossierMedicale dossierMedicale = new DossierMedicale();
            dossierMedicale.setPatient(savedPatient);
            dossierMedicale.setDateCreation(LocalDate.now());
            dossierMedicale.setStatutPaiement(StatutPaiement.INPAYE);
            dossierMedicaleRepository.save(dossierMedicale);

            return savedPatient;
        } catch (Exception e) {
            // Log the error and rethrow an appropriate custom exception
            throw new PatientCreationException("Erreur lors de la création du patient.", e);
        }
    }
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }
    public void deletePatient(Long id) {
        Patient patient = getPatientById(id);
        DossierMedicale dossierMedicale = dossierMedicaleRepository.findByPatientId(id);
        if (dossierMedicale != null) {
            dossierMedicaleRepository.delete(dossierMedicale);
        }
        patientRepository.delete(patient);
    }
    public Patient getPatientById(Long id) {
        return patientRepository.findById(id).orElseThrow(() -> new RuntimeException("Patient not found"));
    }
    public void updatePatient(Long id, Patient updatedPatient) {
        Patient patient = getPatientById(id);
        patient.setNom(updatedPatient.getNom());
        patient.setPrenom(updatedPatient.getPrenom());
        patient.setSexe(updatedPatient.getSexe());
        patient.setEmail(updatedPatient.getEmail());
        patient.setAdresse(updatedPatient.getAdresse());
        patient.setCin(updatedPatient.getCin());
        patient.setTelephone(updatedPatient.getTelephone());
        patient.setDateNaissance(updatedPatient.getDateNaissance());
        patient.setProfession(updatedPatient.getProfession());
        patient.setGroupeSanguin(updatedPatient.getGroupeSanguin());
        patient.setMutuelle(updatedPatient.getMutuelle());
        patientRepository.save(patient);
    }

}
