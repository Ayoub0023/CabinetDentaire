package com.cabinet.cabinetmedicale.repository;

import com.cabinet.cabinetmedicale.entity.DossierMedicale;
import com.cabinet.cabinetmedicale.entity.SituationFinanciere;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SituationFinanciereRepository  extends JpaRepository<SituationFinanciere, Long> {
    SituationFinanciere findByDossierMedicale(DossierMedicale dossierMedicale);
}