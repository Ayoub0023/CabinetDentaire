package com.cabinet.cabinetmedicale.entity;
import com.cabinet.cabinetmedicale.enums.GroupeSanguin;
import com.cabinet.cabinetmedicale.enums.Sexe;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.antlr.v4.runtime.misc.NotNull;

@Entity
@Table(name = "personne")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Inheritance(strategy = InheritanceType.JOINED)

public class Personne {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotNull
    private String nom;
    @NotNull
    private String prenom;
    @NotNull
    private String adresse;
    @NotNull
    private String cin;
    @NotNull
    private String email;
    @NotNull
    private String telephone;
    @Enumerated(EnumType.STRING)
    @NotNull
    private Sexe sexe;

}
