package com.cabinet.cabinetmedicale.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name = "interventionMedecin")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InterventionMedecin {
    @Column(name = "note_Medecin")
    private String noteMedecin;
    private double prixPatient;
    private long dent;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long idIntervention;
    @ManyToOne
    @JoinColumn(name = "consultation_id")
    private Consultation consultation;
    @ManyToOne
    @JoinColumn(name = "acte_id")
    private Acte acte;
}
