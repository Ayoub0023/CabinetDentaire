package com.cabinet.cabinetmedicale.service;

import com.cabinet.cabinetmedicale.entity.Facture;
import com.cabinet.cabinetmedicale.repository.FactureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FactureService {
    private final FactureRepository factureRepository;
    @Autowired
    public FactureService(FactureRepository factureRepository) {
        this.factureRepository = factureRepository;
    }
}
