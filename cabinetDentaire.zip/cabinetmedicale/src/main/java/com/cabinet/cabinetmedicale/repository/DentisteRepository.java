package com.cabinet.cabinetmedicale.repository;

import com.cabinet.cabinetmedicale.entity.Dentiste;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DentisteRepository extends JpaRepository<Dentiste, Long> {

}
