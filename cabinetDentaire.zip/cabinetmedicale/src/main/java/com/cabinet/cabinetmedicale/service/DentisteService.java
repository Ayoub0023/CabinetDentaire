package com.cabinet.cabinetmedicale.service;

import com.cabinet.cabinetmedicale.entity.Dentiste;
import com.cabinet.cabinetmedicale.repository.DentisteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DentisteService {
    private final DentisteRepository dentisteRepository;
    @Autowired
    public DentisteService(DentisteRepository dentisteRepository) {
        this.dentisteRepository = dentisteRepository;
    }
    public Dentiste getDentistById(Long id) {
        return dentisteRepository.findById(id).orElse(null);
    }
    public Dentiste getCurrentDentiste() {
        Long currentDentisteId = getCurrentDentisteId();
        Optional<Dentiste> optionalDentiste = dentisteRepository.findById(currentDentisteId);
        return optionalDentiste.orElseThrow(() -> new RuntimeException("Dentist not found"));
    }

    public void updateDentiste(Dentiste dentiste) {
        Dentiste dentiste1 = dentisteRepository.findById(getCurrentDentisteId()).get();
        dentiste1.setAdresse(dentiste.getAdresse());
        dentiste1.setTelephone(dentiste.getTelephone());
        dentiste1.setEmail(dentiste.getEmail());
        dentisteRepository.save(dentiste1);
    }

    private Long getCurrentDentisteId() {
        return 9L;
    }
}