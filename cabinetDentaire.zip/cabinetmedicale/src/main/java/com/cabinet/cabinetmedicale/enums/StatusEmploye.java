package com.cabinet.cabinetmedicale.enums;

public enum StatusEmploye {
    EN_ARRET_MALADIE,
    AUTRE,
    ENCONGE,
    INACTIF,
    ACTIF
}
