package com.cabinet.cabinetmedicale.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.lang.String;
import java.util.ArrayList;
import java.util.List;
@Entity
@Table(name = "role")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "utilisateur_id")
    private Utilisateur utilisateur;
    @Column(name = "nom_role")
    private String nomRole;
    @ElementCollection
    @CollectionTable(name = "role_privilege",
            joinColumns = @JoinColumn(name = "role_id"))
    @Column(name = "privilege")
    private List<String> privileges;
}
