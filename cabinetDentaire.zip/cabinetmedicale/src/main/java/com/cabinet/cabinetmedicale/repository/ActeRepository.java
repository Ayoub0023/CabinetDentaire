package com.cabinet.cabinetmedicale.repository;

import com.cabinet.cabinetmedicale.entity.Acte;
import com.cabinet.cabinetmedicale.entity.DossierMedicale;
import com.cabinet.cabinetmedicale.entity.Patient;
import com.cabinet.cabinetmedicale.enums.CategorieActe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ActeRepository extends JpaRepository<Acte, Long> {
    Acte findByCategorie(CategorieActe categorieActe);


}
