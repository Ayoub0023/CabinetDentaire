package com.cabinet.cabinetmedicale.dto;

import com.cabinet.cabinetmedicale.enums.CategorieActe;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NewDto {
    private Long dent;//i_m
    private double prix;//i_m
    private LocalDate date;//dm
    private CategorieActe acte;//acte
}
