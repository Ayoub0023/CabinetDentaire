package com.cabinet.cabinetmedicale.controller;

import com.cabinet.cabinetmedicale.entity.Patient;
import com.cabinet.cabinetmedicale.enums.GroupeSanguin;
import com.cabinet.cabinetmedicale.enums.Mutuelle;
import com.cabinet.cabinetmedicale.enums.Sexe;
import com.cabinet.cabinetmedicale.service.PatientService;
import com.cabinet.cabinetmedicale.service.PersonneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/patients")
public class PatientController {

    private final PatientService patientService;
    private final PersonneService personneService;

    @Autowired
    public PatientController(PatientService patientService, PersonneService personneService) {
        this.patientService = patientService;
        this.personneService = personneService;
    }

    @GetMapping
    public String listAndCreatePatients(Model model) {
        List<Patient> patients = patientService.getAllPatients();
        model.addAttribute("patients", patients);
        model.addAttribute("patient", new Patient());
        model.addAttribute("groupeSanguins", GroupeSanguin.values());
        model.addAttribute("mutuelles", Mutuelle.values());
        model.addAttribute("sexes", Sexe.values());
        return "patients";
    }

    @PostMapping
    public String createPatient(@ModelAttribute("patient") Patient patient) {
        patientService.creerPatient(
                patient.getNom(),
                patient.getPrenom(),
                patient.getSexe(),
                patient.getAdresse(),
                patient.getCin(),
                patient.getEmail(),
                patient.getTelephone(),
                patient.getDateNaissance(),
                patient.getProfession(),
                patient.getGroupeSanguin(),
                patient.getMutuelle()
        );
        return "redirect:/patients";
    }
    @PostMapping("/delete/{id}")
    public String deletePatient(@PathVariable("id") Long id) {
        patientService.deletePatient(id);
        return "redirect:/patients";
    }
    @GetMapping("/edit/{id}")
    public String showUpdateForm(@PathVariable("id") Long id, Model model) {
        Patient patient = patientService.getPatientById(id);
        model.addAttribute("patient", patient);
        model.addAttribute("groupeSanguins", GroupeSanguin.values());
        model.addAttribute("mutuelles", Mutuelle.values());
        model.addAttribute("sexes", Sexe.values());
        return "update-patient";
    }
    @PostMapping("/update/{id}")
    public String updatePatient(@PathVariable Long id, @ModelAttribute("patient") Patient patient) {
        patientService.updatePatient(id, patient);
        return "redirect:/patients";
    }
}
