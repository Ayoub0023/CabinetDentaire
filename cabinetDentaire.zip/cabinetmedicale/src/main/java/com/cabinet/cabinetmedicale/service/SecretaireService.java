package com.cabinet.cabinetmedicale.service;

import com.cabinet.cabinetmedicale.repository.SecretaireRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SecretaireService {
    private final SecretaireRepository secretaireRepository;
    @Autowired
    public SecretaireService(SecretaireRepository secretaireRepository) {
        this.secretaireRepository = secretaireRepository;
    }
}

