package com.cabinet.cabinetmedicale.enums;

public enum TypeConsultation {
    SUIVI,
    URGENCE,
    CONSULTATION_GENERALE
}
