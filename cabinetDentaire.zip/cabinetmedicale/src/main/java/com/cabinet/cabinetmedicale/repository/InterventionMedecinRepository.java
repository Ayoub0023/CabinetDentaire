package com.cabinet.cabinetmedicale.repository;

import com.cabinet.cabinetmedicale.dto.NewDto;
import com.cabinet.cabinetmedicale.entity.Consultation;
import com.cabinet.cabinetmedicale.entity.DossierMedicale;
import com.cabinet.cabinetmedicale.entity.InterventionMedecin;
import com.cabinet.cabinetmedicale.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InterventionMedecinRepository extends JpaRepository<InterventionMedecin, Long> {
    InterventionMedecin findByConsultation(Consultation consultation);
    List<InterventionMedecin> findAllByConsultation (Consultation consultation);

    // In your repository
    @Query("SELECT i.dent, i.acte, i.prixPatient, c.dateConsultation " +
            "FROM InterventionMedecin i " +
            "JOIN i.consultation c " +
            "JOIN c.dossierMedicale d " +
            "WHERE d.patient.id = :patientId")
    List<Object[]> findInterventionsByPatientId(@Param("patientId") Long patientId);

    // In your service


}
