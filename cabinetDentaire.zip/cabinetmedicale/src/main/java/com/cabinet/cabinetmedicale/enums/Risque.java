package com.cabinet.cabinetmedicale.enums;

public enum Risque {
    FAIBLE,
    MOYEN,
    ELEVE,
    INCONNU
}
