package com.cabinet.cabinetmedicale.controller;

import com.cabinet.cabinetmedicale.entity.Dentiste;
import com.cabinet.cabinetmedicale.entity.Patient;
import com.cabinet.cabinetmedicale.enums.*;
import com.cabinet.cabinetmedicale.service.PatientService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import com.cabinet.cabinetmedicale.service.DentisteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class DentisteController {
    private final DentisteService dentisteService;
    private final PatientService patientService;

    @Autowired
    public DentisteController(DentisteService dentisteService, PatientService patientService) {
        this.dentisteService = dentisteService;
        this.patientService = patientService;
    }
    @GetMapping("/profil")
    public String getDentistProfile(Model model) {
        // Assuming you have a method to get the currently logged-in dentist
        Dentiste dentiste = dentisteService.getCurrentDentiste();
        model.addAttribute("dentiste", dentiste);
        return "profil";
    }

    @GetMapping("/updateProfil")
    public String modifierProfil(Model model) {
        Dentiste dentiste = dentisteService.getCurrentDentiste();
        model.addAttribute("dentiste", dentiste);
        return "update_profil";
    }

    @PostMapping("/updateProfil")
    public String updateProfil(@ModelAttribute("dentiste") Dentiste dentiste) {
        dentisteService.updateDentiste(dentiste);
        return "redirect:/profil";
    }

}
