package com.cabinet.cabinetmedicale.service;

import com.cabinet.cabinetmedicale.dto.ConsultationDTO;
//import com.cabinet.cabinetmedicale.dto.NewDto;
import com.cabinet.cabinetmedicale.dto.NewDto;
import com.cabinet.cabinetmedicale.dto.SituationFinanciereDto;
import com.cabinet.cabinetmedicale.entity.*;
import com.cabinet.cabinetmedicale.enums.CategorieActe;
import com.cabinet.cabinetmedicale.repository.*;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.Optional;

@Service
public class DossierMedicaleService {
    private final DossierMedicaleRepository dossierMedicaleRepository;
    private final InterventionMedecinRepository interventionMedecinRepository;
    private final ActeRepository acteRepository;
    private final PatientRepository patientRepository;
    private final ConsultationRepository consultationRepository;
    private final SituationFinanciereRepository situationFinanciereRepository;
    private final FactureRepository factureRepository;

    @Autowired
    public DossierMedicaleService(DossierMedicaleRepository dossierMedicaleRepository,
                                  PatientRepository patientRepository,
                                  InterventionMedecinRepository interventionMedecinRepository,
                                  ActeRepository acteRepository,
                                  ConsultationRepository consultationRepository,
                                  SituationFinanciereRepository situationFinanciereRepository,
                                  FactureRepository factureRepository) {
        this.dossierMedicaleRepository = dossierMedicaleRepository;
        this.patientRepository = patientRepository;
        this.interventionMedecinRepository = interventionMedecinRepository;
        this.acteRepository = acteRepository;
        this.consultationRepository = consultationRepository;
        this.situationFinanciereRepository = situationFinanciereRepository;
        this.factureRepository = factureRepository;
    }

    public Double calculeMontant(List<NewDto> interventions) {
        return interventions.stream().mapToDouble(NewDto::getPrix).sum();
    }

    public SituationFinanciereDto mapToNewDtoSf(Facture facture, Long patientId) {
        SituationFinanciereDto situationFinanciereDto = new SituationFinanciereDto();
        situationFinanciereDto.setDate(facture.getDateFacturation());
        situationFinanciereDto.setEtat(facture.getSituationFinanciere().getDossierMedicale().getStatutPaiement());
        situationFinanciereDto.setMontant(calculeMontant(getInterventionsByPatientId(patientId)));
        situationFinanciereDto.setNumeroFacture(facture.getId());
        return situationFinanciereDto;
    }

    public NewDto mapToNewDto(InterventionMedecin interventionMedecin) {
        NewDto newDto = new NewDto();
        newDto.setActe(interventionMedecin.getActe().getCategorie());
        newDto.setDent(interventionMedecin.getDent());
        newDto.setPrix(interventionMedecin.getPrixPatient());
        newDto.setDate(interventionMedecin.getConsultation().getDateConsultation());
        return newDto;
    }

    public List<NewDto> getInterventionsByPatientId(Long patientId) {
        List<NewDto> newDtos = new ArrayList<>();
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient not found"));
        DossierMedicale dossierMedicale = dossierMedicaleRepository.findByPatient(patient);
        if (dossierMedicale == null) {
            throw new RuntimeException("Dossier Medicale not found");
        }
        Consultation consultation = consultationRepository.findByDossierMedicale(dossierMedicale);
        if (consultation == null) {
            throw new RuntimeException("Consultation not found");
        }
        List<InterventionMedecin> interventionsMedecin = interventionMedecinRepository.findAllByConsultation(consultation);
        for (InterventionMedecin interventionMedecin : interventionsMedecin) {
            newDtos.add(mapToNewDto(interventionMedecin));
        }
        return newDtos;
    }

    public List<SituationFinanciereDto> getSituationsFinanciereByPatientId(Long patientId) {
        List<SituationFinanciereDto> situationsFinanciereDto = new ArrayList<>();
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient not found"));
        DossierMedicale dossierMedicale = dossierMedicaleRepository.findByPatient(patient);
        if (dossierMedicale == null) {
            throw new RuntimeException("Dossier Medicale not found");
        }
        Consultation consultation = consultationRepository.findByDossierMedicale(dossierMedicale);
        if (consultation == null) {
            throw new RuntimeException("Consultation not found");
        }
        List<Facture> factures = factureRepository.findAllByConsultation(consultation);
        for (Facture facture : factures) {
            situationsFinanciereDto.add(mapToNewDtoSf(facture, patientId));
        }
        return situationsFinanciereDto;
    }
//    public void creerConsultation(CategorieActe categorieActe, Long dent, Double prix, Long id) {
//        NewDto newDto = new NewDto();
//        newDto.setActe(categorieActe);
//        newDto.setDent(dent);
//        newDto.setPrix(prix);
//        newDto.setDate(LocalDate.now());
//        DossierMedicale dossierMedicale = dossierMedicaleRepository.findByPatientId(id);
//        Consultation consultation = new Consultation();
//        consultation.setDateConsultation(newDto.getDate());
//        consultation.setDossierMedicale(dossierMedicale);
//        consultationRepository.save(consultation);
//
//        Acte acte = new Acte();
//        acte.setCategorie(newDto.getActe());
//        acteRepository.save(acte); // Save Acte before setting it in InterventionMedecin
//
//        InterventionMedecin interventionMedecin = new InterventionMedecin();
//        interventionMedecin.setDent(newDto.getDent());
//        interventionMedecin.setActe(acte);
//        interventionMedecinRepository.save(interventionMedecin);
//    }


}

