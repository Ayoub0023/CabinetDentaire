package com.cabinet.cabinetmedicale.service;

import com.cabinet.cabinetmedicale.entity.Utilisateur;
import com.cabinet.cabinetmedicale.repository.UtilisateurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UtilisateurService {

    private final UtilisateurRepository utilisateurRepository;

    @Autowired
    public UtilisateurService(UtilisateurRepository utilisateurRepository) {
        this.utilisateurRepository = utilisateurRepository;

    }
    public Utilisateur login(String nomUtilisateur, String motDePasse) {
        return utilisateurRepository.findByNomUtilisateurAndMotDePasse(nomUtilisateur, motDePasse)
                .orElseThrow(() -> new IllegalArgumentException("Invalid username or password"));
    }

//    public Utilisateur saveUtilisateur(Utilisateur utilisateur) {
//        return utilisateurRepository.save(utilisateur);
//    }

//    public List<Utilisateur> getUtilisateurs() {
//        return utilisateurRepository.findAll();
//    }
//
//    public Utilisateur getUtilisateurById(Long id) {
//        return utilisateurRepository.findById(id).orElse(null);
//    }

//    public Utilisateur getUtilisateurByNomUtilisateur(String nomUtilisateur) {
//        return utilisateurRepository.findByNomUtilisateur(nomUtilisateur);
//    }

//    public List<Utilisateur> getUtilisateursByRole(String nomRole) {
//        return utilisateurRepository.findByRoles_NomRole(nomRole);
//    }

//    public void deleteUtilisateur(Long id) {
//        utilisateurRepository.deleteById(id);
//    }

    // Other service methods using utilisateurRepository
}