package com.cabinet.cabinetmedicale.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Entity
@Table(name = "utilisateur")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Utilisateur extends Personne {
    private String nomUtilisateur;
    private String motDePasse;
    @OneToMany(mappedBy = "utilisateur")
    private List<Role> roles = new ArrayList<>();
}
