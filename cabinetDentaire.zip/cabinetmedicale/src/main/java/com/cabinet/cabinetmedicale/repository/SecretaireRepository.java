package com.cabinet.cabinetmedicale.repository;

import com.cabinet.cabinetmedicale.entity.Secretaire;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SecretaireRepository extends JpaRepository<Secretaire, Long> {
}

