package com.cabinet.cabinetmedicale.enums;

public enum TypePaiement {
    CHEQUE,
    VIREMENT,
    ESPECE,
    AUTE,
    CARTE_CREDIT
}
