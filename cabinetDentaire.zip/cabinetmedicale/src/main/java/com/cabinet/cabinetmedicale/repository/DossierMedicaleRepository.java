package com.cabinet.cabinetmedicale.repository;

import com.cabinet.cabinetmedicale.entity.DossierMedicale;
import com.cabinet.cabinetmedicale.entity.Patient;
import com.cabinet.cabinetmedicale.entity.SituationFinanciere;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

@Repository
public interface DossierMedicaleRepository extends JpaRepository<DossierMedicale, Long> {
    DossierMedicale findByPatient(Patient patient);
    DossierMedicale findByDateCreation(LocalDate localDate);
    DossierMedicale findByPatientId(Long patientId);
}
