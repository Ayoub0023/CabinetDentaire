package com.cabinet.cabinetmedicale.service;

import com.cabinet.cabinetmedicale.repository.ActeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ActeService {
    private final ActeRepository acteRepository;
    @Autowired
    public ActeService(ActeRepository acteRepository) {
        this.acteRepository = acteRepository;
    }
}
