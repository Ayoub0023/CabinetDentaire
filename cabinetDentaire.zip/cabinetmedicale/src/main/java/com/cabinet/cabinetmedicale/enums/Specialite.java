package com.cabinet.cabinetmedicale.enums;

public enum Specialite {
    ENDODONTIE,
    CHIRURGIE_DENTAIRE,
    PROTHESE,
    ORTHODONTIE,
    PARODONTOLOGIE,
    AUTRE

}
