package com.cabinet.cabinetmedicale.controller;

import com.cabinet.cabinetmedicale.dto.ConsultationDTO;
import com.cabinet.cabinetmedicale.dto.NewDto;
import com.cabinet.cabinetmedicale.dto.SituationFinanciereDto;
import com.cabinet.cabinetmedicale.entity.Patient;
import com.cabinet.cabinetmedicale.enums.CategorieActe;
import com.cabinet.cabinetmedicale.enums.GroupeSanguin;
import com.cabinet.cabinetmedicale.enums.Mutuelle;
import com.cabinet.cabinetmedicale.enums.Sexe;
import com.cabinet.cabinetmedicale.service.DossierMedicaleService;
import com.cabinet.cabinetmedicale.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
@Controller
@RequestMapping("/patients")
public class DossierMedicaleController {
    private final DossierMedicaleService dossierMedicaleService;
    private final PatientService patientService;


    @Autowired
    public DossierMedicaleController(DossierMedicaleService dossierMedicaleService, PatientService patientService) {
        this.dossierMedicaleService = dossierMedicaleService;
        this.patientService = patientService;
    }
@GetMapping("/dossier_medicale/{id}")
  public String listConsultation(Model model, @PathVariable("id")Long id){
        Patient patient= patientService.getPatientById(id);
        List<NewDto> actes=dossierMedicaleService.getInterventionsByPatientId(id);
        List<SituationFinanciereDto> situationsFinanciereDto=dossierMedicaleService.getSituationsFinanciereByPatientId(id);
        List<CategorieActe>categoriesActe=new ArrayList<>();
        categoriesActe.add(CategorieActe.CHIRURGIE);
        categoriesActe.add(CategorieActe.IMPLANTOLOGIE);
        categoriesActe.add(CategorieActe.ORTHODONTIE);
        categoriesActe.add(CategorieActe.PREVENTION);
        categoriesActe.add(CategorieActe.PROTHESES_DENTAIRES);
        categoriesActe.add(CategorieActe.DIAGNOSTIC);
        categoriesActe.add(CategorieActe.SOINS_DES_TISSUS_MOUS);
        categoriesActe.add(CategorieActe.SOINS_DES_CARIES);
        NewDto consultation=new NewDto();
        Long idd=id;
        model.addAttribute("actes",actes);
        model.addAttribute("factures",situationsFinanciereDto);
        model.addAttribute("patient",patient);
        model.addAttribute("consultation",consultation);
        model.addAttribute("categoriesActe",categoriesActe);
        model.addAttribute("idd",idd);
    return "dossier_medicale";
  }
//    @PostMapping("/createconsultation/{id}")
//    public String createConsultation(@ModelAttribute("consultation") NewDto newDto, @PathVariable("id") Long id) {
//        dossierMedicaleService.creerConsultation(
//                newDto.getActe(),
//                newDto.getDent(),
//                newDto.getPrix(),
//                id
//        );
//        return "redirect:/patients/dossier_medicale/" + id;
//    }
}
