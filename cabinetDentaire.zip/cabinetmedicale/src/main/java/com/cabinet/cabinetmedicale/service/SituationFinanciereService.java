package com.cabinet.cabinetmedicale.service;

import com.cabinet.cabinetmedicale.dto.ConsultationDTO;
import com.cabinet.cabinetmedicale.dto.SituationFinanciereDto;
import com.cabinet.cabinetmedicale.entity.*;
import com.cabinet.cabinetmedicale.repository.DossierMedicaleRepository;
import com.cabinet.cabinetmedicale.repository.FactureRepository;
import com.cabinet.cabinetmedicale.repository.PatientRepository;
import com.cabinet.cabinetmedicale.repository.SituationFinanciereRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SituationFinanciereService {
    private final SituationFinanciereRepository situationFinanciereRepository;

    @Autowired
    public SituationFinanciereService(SituationFinanciereRepository situationFinanciereRepository, PatientRepository patientRepository, DossierMedicaleRepository dossierMedicaleRepository, FactureRepository factureRepository)
    {
        this.situationFinanciereRepository = situationFinanciereRepository;

    }
}

