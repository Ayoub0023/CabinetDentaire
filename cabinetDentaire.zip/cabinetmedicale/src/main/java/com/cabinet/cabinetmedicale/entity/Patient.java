package com.cabinet.cabinetmedicale.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cabinet.cabinetmedicale.enums.GroupeSanguin;
import com.cabinet.cabinetmedicale.enums.Mutuelle;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.antlr.v4.runtime.misc.NotNull;
import org.hibernate.annotations.CreationTimestamp;
@Entity
@Table(name = "patient")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Patient extends Personne  {
    @CreationTimestamp
    @NotNull
    private LocalDate dateNaissance;
    @NotNull
    private String profession;
    @Enumerated(EnumType.STRING)
    @NotNull
    private GroupeSanguin groupeSanguin;
    @Enumerated(EnumType.STRING)
    @NotNull
    private Mutuelle mutuelle;
    @NotNull
    @ManyToMany
            (mappedBy = "patientsAvecCeAntecedentMedicale")
    private List<AntecedentMedicale> antecedentsMedicaux;
    public void addAntecedentMedicale(AntecedentMedicale antecedentMedicale)
    {
     if(this.antecedentsMedicaux==null)
        this.antecedentsMedicaux=new ArrayList<>();
     antecedentsMedicaux.add(antecedentMedicale);
    }
}
// si jai utiliser classe adresse @embeddable
// @embedded
//private Adresse adresse;