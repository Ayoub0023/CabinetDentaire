package com.cabinet.cabinetmedicale.controller;
import org.springframework.ui.Model;
import com.cabinet.cabinetmedicale.entity.Utilisateur;
import com.cabinet.cabinetmedicale.service.UtilisateurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    @Autowired
    private UtilisateurService utilisateurService;

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String nomUtilisateur, @RequestParam String motDePasse, Model model) {
        try {
            Utilisateur utilisateur = utilisateurService.login(nomUtilisateur, motDePasse);
            model.addAttribute("utilisateur", utilisateur);
            return "redirect:/patients";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "login";
        }
    }
}
