package com.cabinet.cabinetmedicale.entity;
import com.cabinet.cabinetmedicale.enums.TypeConsultation;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
@Entity
@Table(name = "consultation")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Consultation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @ManyToOne
    @JoinColumn(name = "dossierMedical_id")
    private DossierMedicale dossierMedicale;
    @CreationTimestamp
    private LocalDate dateConsultation;
    private TypeConsultation typeConsultation;
    @OneToMany(mappedBy = "consultation")
    private List<InterventionMedecin> interventionsMedecin =new ArrayList<>();
    @OneToMany(mappedBy = "consultation")
    private List<Facture> factures =new ArrayList<>();
}
