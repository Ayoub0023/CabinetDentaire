package com.cabinet.cabinetmedicale.entity;

import com.cabinet.cabinetmedicale.enums.CategorieActe;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="acte")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Acte {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long idActe;
    private String libelle;
        @OneToMany(mappedBy = "acte")
        private List<InterventionMedecin> interventionsMedecin =new ArrayList<>();
    private double prixDeBase;
    @Enumerated(EnumType.STRING)
    private CategorieActe categorie;
}
