package com.cabinet.cabinetmedicale.enums;

public enum Mutuelle {
    CNAM,
    CIMR,
    CNSS,
    CNOPS
}
