package com.cabinet.cabinetmedicale.enums;
public enum Assurance{
    CNOPS,
    CIMR,
    CNSS,
    AUTRE
}